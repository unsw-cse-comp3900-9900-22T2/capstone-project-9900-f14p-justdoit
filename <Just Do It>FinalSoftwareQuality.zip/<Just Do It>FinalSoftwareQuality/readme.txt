*Our team name: Just Do It

*file name is:
<Just Do It>FinalSoftwareQuality.zip
* file link :
https://github.com/unsw-cse-comp3900-9900-22T2/capstone-project-9900-f14p-justdoit/blob/main/%3CJust%20Do%20It%3EFinalSoftwareQuality.zip

* Our team’s GitHub classroom assignment repository link is:
https://github.com/unsw-cse-comp3900-9900-22T2/capstone-project-9900-f14p-justdoit

*branch is “main”

* commit account is: kelurlucky 

