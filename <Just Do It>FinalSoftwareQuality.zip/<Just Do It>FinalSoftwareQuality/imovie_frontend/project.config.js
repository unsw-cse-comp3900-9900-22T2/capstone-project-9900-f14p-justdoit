module.exports = {
    localDomain: "",
    urlPrefix: "",
    vendor: "app_name",
}