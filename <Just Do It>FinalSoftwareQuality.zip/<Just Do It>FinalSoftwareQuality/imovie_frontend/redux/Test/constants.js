export const GET_TIME = "GET_TIME";
export const GET_TIME_SUCCESS = "GET_TIME_SUCCESS";
export const GET_TIME_FAIL = "GET_TIME_FAIL";